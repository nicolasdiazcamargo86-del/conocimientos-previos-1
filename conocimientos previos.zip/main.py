class Persona:
    def __init__(self, nombre: str, genero: str):
        self.nombre = nombre
        self.genero = genero

class Examen:
    def __init__(self, materia: str, nota: float):
        self.materia = materia
        self.nota = nota

    def es_regular(self) -> bool:
        return 2.5 < self.nota <= 3.5

    def es_reprobado(self) -> bool:
        return self.nota <= 2.5

class Estudiante(Persona):
    registro_global_examenes = []

    def __init__(self, id_estudiante: int, nombre: str, genero: str):
        super().__init__(nombre, genero)
        self.id_estudiante = id_estudiante
        self.examenes = []

    def agregar_examen(self, materia: str, nota: float):
        examen = Examen(materia, nota)
        self.examenes.append(examen)
        Estudiante.registro_global_examenes.append((self, examen))

    def contarRegulares(self) -> int:
        return sum(1 for examen in self.examenes if examen.es_regular())

    @classmethod
    def contar_regulares_grupo(cls) -> int:
        return sum(1 for _, examen in cls.registro_global_examenes if examen.es_regular())

diccionario_estudiantes = {
    1: ("armando", "m"),
    2: ("nicolas", "m"),
    3: ("daniel", "m"),
    4: ("maria", "f"),
    5: ("marcela", "f"),
    6: ("alexandra", "f")
}

diccionario_materias = {
    1: "quimica",
    2: "idiomas",
    3: "historia"
}

datos_entrada = [
    (1.0, 0.0, 1.0, 1.1),
    (1.0, 0.0, 2.0, 1.8),
    (1.0, 0.0, 3.0, 3.3),
    (2.0, 0.0, 1.0, 4.3),
    (2.0, 0.0, 2.0, 1.6),
    (2.0, 0.0, 3.0, 4.3),
    (3.0, 0.0, 1.0, 3.8),
    (3.0, 0.0, 2.0, 0.7),
    (3.0, 0.0, 3.0, 1.8),
    (4.0, 1.0, 1.0, 0.6),
    (4.0, 1.0, 2.0, 2.5),
    (4.0, 1.0, 3.0, 4.0),
    (5.0, 1.0, 1.0, 0.5),
    (5.0,),
]
